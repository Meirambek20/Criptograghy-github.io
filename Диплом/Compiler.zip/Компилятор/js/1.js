// Шифрларды көрсету функциясы
function showCipher() {
    const cipherSelect = document.getElementById('cipher-select').value;
    const sections = document.getElementsByClassName('cipher-section');

    // Барлық шифр секцияларын жасыру
    for (let section of sections) {
        section.style.display = 'none';
    }

    // Таңдалған шифрдың секциясын көрсету
    if (cipherSelect) {
        document.getElementById(`${cipherSelect}-section`).style.display = 'block';
    }
}

// Цезарь шифры
function caesarEncrypt() {
    const text = document.getElementById('caesar-input').value;
    const shift = parseInt(document.getElementById('caesar-shift').value);
    let result = '';

    for (let i = 0; i < text.length; i++) {
        const char = text[i];

        if (char.match(/[a-z]/i)) { // Әріптерді тексеру
            const code = text.charCodeAt(i);
            const offset = (code >= 65 && code <= 90) ? 65 : 97; // Жоғары және төменгі регистр үшін
            result += String.fromCharCode(((code - offset + shift) % 26) + offset);
        } else {
            result += char; // Егер әріп болмаса, символды өзгеріссіз қосу
        }
    }
    document.getElementById('caesar-output').textContent = result;
}

function caesarDecrypt() {
    const text = document.getElementById('caesar-input').value;
    const shift = parseInt(document.getElementById('caesar-shift').value);
    let result = '';

    for (let i = 0; i < text.length; i++) {
        const char = text[i];

        if (char.match(/[a-z]/i)) { // Әріптерді тексеру
            const code = text.charCodeAt(i);
            const offset = (code >= 65 && code <= 90) ? 65 : 97; // Жоғары және төменгі регистр үшін
            result += String.fromCharCode(((code - offset - shift + 26) % 26) + offset);
        } else {
            result += char; // Егер әріп болмаса, символды өзгеріссіз қосу
        }
    }
    document.getElementById('caesar-output').textContent = result;
}

// Виженер шифры
function vigenereEncrypt() {
    const text = document.getElementById('vigenere-input').value.toLowerCase();
    const key = document.getElementById('vigenere-key').value.toLowerCase();
    let result = '';
    let keyIndex = 0;

    for (let i = 0; i < text.length; i++) {
        const char = text[i];
        if (char.match(/[a-z]/)) {
            const textCharCode = char.charCodeAt(0) - 97;
            const keyCharCode = key[keyIndex % key.length].charCodeAt(0) - 97;
            result += String.fromCharCode(((textCharCode + keyCharCode) % 26) + 97);
            keyIndex++;
        } else {
            result += char;
        }
    }
    document.getElementById('vigenere-output').textContent = result;
}

function vigenereDecrypt() {
    const text = document.getElementById('vigenere-input').value.toLowerCase();
    const key = document.getElementById('vigenere-key').value.toLowerCase();
    let result = '';
    let keyIndex = 0;

    for (let i = 0; i < text.length; i++) {
        const char = text[i];
        if (char.match(/[a-z]/)) {
            const textCharCode = char.charCodeAt(0) - 97;
            const keyCharCode = key[keyIndex % key.length].charCodeAt(0) - 97;
            result += String.fromCharCode(((textCharCode - keyCharCode + 26) % 26) + 97);
            keyIndex++;
        } else {
            result += char;
        }
    }
    document.getElementById('vigenere-output').textContent = result;
}

// Гронсфельд шифры
function gronsfeldEncrypt() {
    const text = document.getElementById('gronsfeld-input').value;
    const key = document.getElementById('gronsfeld-key').value;
    let result = '';
    let keyIndex = 0;

    for (let i = 0; i < text.length; i++) {
        const char = text[i];

        if (char.match(/[0-9a-z]/i)) {
            const shift = parseInt(key[keyIndex % key.length]) % 10;
            const code = char.charCodeAt(0);
            const offset = (code >= 65 && code <= 90) ? 65 : (code >= 97 && code <= 122) ? 97 : (code >= 48 && code <= 57) ? 48 : -1;

            if (offset !== -1) {
                result += String.fromCharCode(((code - offset + shift) % 26) + offset);
                keyIndex++;
            } else {
                result += char;
            }
        } else {
            result += char;
        }
    }
    document.getElementById('gronsfeld-output').textContent = result;
}

function gronsfeldDecrypt() {
    const text = document.getElementById('gronsfeld-input').value;
    const key = document.getElementById('gronsfeld-key').value;
    let result = '';
    let keyIndex = 0;

    for (let i = 0; i < text.length; i++) {
        const char = text[i];

        if (char.match(/[0-9a-z]/i)) {
            const shift = parseInt(key[keyIndex % key.length]) % 10;
            const code = char.charCodeAt(0);
            const offset = (code >= 65 && code <= 90) ? 65 : (code >= 97 && code <= 122) ? 97 : (code >= 48 && code <= 57) ? 48 : -1;

            if (offset !== -1) {
                result += String.fromCharCode(((code - offset - shift + 26) % 26) + offset);
                keyIndex++;
            } else {
                result += char;
            }
        } else {
            result += char;
        }
    }
    document.getElementById('gronsfeld-output').textContent = result;
}
// Морзе шифры
const morseCode = {
    'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 
    'F': '..-.', 'G': '--.', 'H': '....', 'I': '..', 'J': '.---', 
    'K': '-.-', 'L': '.-..', 'M': '--', 'N': '-.', 'O': '---', 
    'P': '.--.', 'Q': '--.-', 'R': '.-.', 'S': '...', 'T': '-', 
    'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-', 'Y': '-.--', 
    'Z': '--..', '1': '.----', '2': '..---', '3': '...--', 
    '4': '....-', '5': '.....', '6': '-....', '7': '--...', 
    '8': '---..', '9': '----.', '0': '-----', ' ': '/'
};

function morseEncrypt() {
    const text = document.getElementById('morse-input').value.toUpperCase();
    let result = '';

    for (let char of text) {
        result += morseCode[char] + ' ';
    }
    document.getElementById('morse-output').textContent = result.trim();
}

function morseDecrypt() {
    const text = document.getElementById('morse-input').value.trim();
    const morseArray = text.split(' ');
    let result = '';

    for (let code of morseArray) {
        const char = Object.keys(morseCode).find(key => morseCode[key] === code);
        result += char ? char : '';
    }
    document.getElementById('morse-output').textContent = result;
}

// Шифрларды көрсету функциясы
function showCipher() {
    const cipherSelect = document.getElementById('cipher-select').value;
    const sections = document.getElementsByClassName('cipher-section');
    const infoCards = document.getElementsByClassName('info-card');

    // Барлық шифр секцияларын жасыру
    for (let section of sections) {
        section.style.display = 'none';
    }

    // Барлық ақпарат карточкаларын жасыру
    for (let card of infoCards) {
        card.style.display = 'none';
    }

    // Таңдалған шифрдың секциясын және ақпарат карточкасын көрсету
    if (cipherSelect) {
        document.getElementById(`${cipherSelect}-section`).style.display = 'block';
        document.getElementById(`${cipherSelect}-info`).style.display = 'block';
    }
}

// Трисемус шифры (Trithemius Cipher)
function trithemiusEncrypt() {
    const text = document.getElementById('trithemius-input').value;
    let result = '';
    
    for (let i = 0; i < text.length; i++) {
        const char = text.charCodeAt(i);

        if (char >= 65 && char <= 90) {  // Латын бас әріптері
            result += String.fromCharCode(((char - 65 + i) % 26) + 65);
        } else if (char >= 97 && char <= 122) {  // Латын кіші әріптері
            result += String.fromCharCode(((char - 97 + i) % 26) + 97);
        } else {
            result += text[i];
        }
    }

    document.getElementById('trithemius-output').textContent = result;
}

function trithemiusDecrypt() {
    const text = document.getElementById('trithemius-input').value;
    let result = '';

    for (let i = 0; i < text.length; i++) {
        const char = text.charCodeAt(i);

        if (char >= 65 && char <= 90) {  // Латын бас әріптері
            result += String.fromCharCode(((char - 65 - i + 26) % 26) + 65);
        } else if (char >= 97 && char <= 122) {  // Латын кіші әріптері
            result += String.fromCharCode(((char - 97 - i + 26) % 26) + 97);
        } else {
            result += text[i];
        }
    }

    document.getElementById('trithemius-output').textContent = result;
}
const trisemusKey = [
    ['A', 'B', 'C'],
    ['D', 'E', 'F'],
    ['G', 'H', 'I'],
    ['J', 'K', 'L'],
    ['M', 'N', 'O'],
    ['P', 'Q', 'R'],
    ['S', 'T', 'U'],
    ['V', 'W', 'X'],
    ['Y', 'Z', ' '],
];

function trisemusEncrypt(text) {
    let result = '';
    text = text.toUpperCase(); // Мәтінді жоғарғы регистрге айналдыру

    for (let char of text) {
        for (let i = 0; i < trisemusKey.length; i++) {
            if (trisemusKey[i].includes(char)) {
                const col = trisemusKey[i].indexOf(char);
                result += (i + 1) + '' + (col + 1); // Нәтижеге жол мен баған нөмірін қосу
            }
        }
    }
    return result;
}

function trisemusDecrypt(cipher) {
    let result = '';
    const pairs = cipher.match(/(\d)(\d)/g); // Нөмірлерді жұптап бөліп алу

    for (let pair of pairs) {
        const row = parseInt(pair[0]) - 1; // Жол нөмірін алу
        const col = parseInt(pair[1]) - 1; // Баған нөмірін алу
        result += trisemusKey[row][col]; // Матрицадан символды алу
    }
    return result;
}

// Пайдалану
const textToEncrypt = 'HELLO';
const encrypted = trisemusEncrypt(textToEncrypt);
console.log('Шифрланған:', encrypted);

const decrypted = trisemusDecrypt(encrypted);
console.log('Дешифрланған:', decrypted);
